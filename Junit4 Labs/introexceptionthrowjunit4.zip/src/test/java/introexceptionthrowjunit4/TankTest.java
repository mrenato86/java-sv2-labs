package introexceptionthrowjunit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class TankTest {

    private Tank tank = new Tank();

    @Test
    public void modifyAngleTest() {
        tank.modifyAngle(2090);
        assertEquals(290, tank.getAngle());

        tank.modifyAngle(-2020);
        assertEquals(70, tank.getAngle());
    }

    @Test(expected = IllegalArgumentException.class)
    public void modifyAngleTestExpect() {
        tank.modifyAngle(2000);
    }

    @Rule
    public ExpectedException expectedException = ExpectedException.none();

    @Test
    public void modifyAngleTestRule() {
        expectedException.expect(IllegalArgumentException.class);
        expectedException.expectMessage("Turret can't be in a position between 80° and 280°!");
        tank.modifyAngle(2000);
    }

    @Test
    public void modifyAngleTestLambda() {
        IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, () -> tank.modifyAngle(2000));
        assertEquals("Turret can't be in a position between 80° and 280°!", iae.getMessage());
    }

}