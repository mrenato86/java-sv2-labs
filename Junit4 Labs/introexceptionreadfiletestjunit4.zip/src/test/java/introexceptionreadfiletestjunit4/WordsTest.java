package introexceptionreadfiletestjunit4;

import org.junit.Test;

import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class WordsTest {

    private Words words = new Words();

    @Test
    public void testGetFirstWordWithAValid() {
        Path validFile = Paths.get("src/test/resources/introexceptionreadfiletestjunit4/words.txt");
        assertEquals("Anna", words.getFirstWordWithA(validFile));
    }

    @Test
    public void testGetFirstWordWithAInvalid() {
        Path invalidFile = Paths.get("src/test/resources/introexceptionreadfiletestjunit4/wordsNoA.txt");
        assertEquals("A", words.getFirstWordWithA(invalidFile));
    }

    @Test
    public void testGetFirstWordWithANoFile() {
        Path noFile = Paths.get("src/test/resources/introexceptionreadfiletestjunit4/noWords.txt");
        IllegalStateException ise = assertThrows(IllegalStateException.class, () -> words.getFirstWordWithA(noFile));
        assertEquals("File reading error!", ise.getMessage());
    }
}