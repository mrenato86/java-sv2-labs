package introexceptionreadfiletestjunit4;

import org.junit.Test;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class RecipeTest {

    private Recipe recipe = new Recipe();

    @Test
    public void testAddIngredients() {
        Path file = Paths.get("src/test/resources/introexceptionreadfiletestjunit4/recipe.txt");
        recipe.addIngredients(file);
        List<String> expected = List.of("liszt", "margarin", "kristálycukor", "tojás", "citrom",
                "sütőpor", "vanillincukor", "tejföl", "alma", "fahéj");
        assertEquals(expected, recipe.getIngredients());
    }

    @Test
    public void testAddIngredientsNoFile() {
        Path noFile = Paths.get("src/test/resources/introexceptionreadfiletestjunit4/NoRecipe.txt");
        IllegalStateException ise = assertThrows(IllegalStateException.class, () -> recipe.addIngredients(noFile));
        assertEquals("File reading error!", ise.getMessage());
    }
}