package introjunit;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class GentlemanTest {

    @Test
    public void testHello() {
        //Given
        Gentleman gentleman = new Gentleman();
        //When
        String greeting = gentleman.sayHello("John Doe");
        //Then
        assertEquals("Hello John Doe", greeting);
    }

    @Test
    public void testHelloNull() {
        //Given
        Gentleman gentleman = new Gentleman();
        //When
        String greeting = gentleman.sayHello(null);
        //Then
        assertEquals("Hello Anonymous", greeting);
    }


}
