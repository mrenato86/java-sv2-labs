package introexceptionwritefiletestjunit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;

public class BookTest {

    private Book book = new Book();

    @Rule
    public TemporaryFolder temporaryFolder = new TemporaryFolder();

    @Test
    public void testWriteBooks() throws IOException {
        List<String> expected = List.of("Gárdonyi Géza: Egri csillagok", "Molnár Ferenc: Pál utcai fiúk",
                "Fekete István: Tüskevár", "Jókai Mór: Kőszívű ember fiai");

        Path source = Paths.get("src/test/resources/introexceptionwritefiletestjunit4/books.txt");
        Path tempFile = temporaryFolder.newFile("readableBooks.txt").toPath();
        book.writeBooks(source, tempFile);

        assertEquals(expected, Files.readAllLines(tempFile));
    }

    @Test
    public void testWriteBooksException() throws IOException {
        Path wrongSource = Paths.get("src/test/resources/introexceptionwritefiletestjunit4/NoBooks.txt");
        Path tempFile = temporaryFolder.newFile("readableBooks.txt").toPath();
        IllegalStateException ise = assertThrows(IllegalStateException.class, () -> book.writeBooks(wrongSource, tempFile));
        assertEquals("File reading error!", ise.getMessage());
    }
}