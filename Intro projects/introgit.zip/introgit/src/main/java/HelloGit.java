public class HelloGit {

    public static void main(String[] args) {
        System.out.println("Hello IDEA & Git!");
    }
}
